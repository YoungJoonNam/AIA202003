package com.wifi.order.dao;

public interface PurchaseDao {

}
